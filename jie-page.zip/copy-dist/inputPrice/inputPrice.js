// pages/inputPrice/inputPrice.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    mPirce:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  /**
 * 输入监听收信人
 */
  inputTilte2: function (e) {
    let that = this;
    that.data.mPirce = e.detail.value;
  },

  goPrice:function(){
    let that = this;
    var tPrice = parseFloat(that.data.mPirce).toFixed(2)

    if( tPrice < 100 ){
      wx.showToast({
        title: '收款金额必须大于等于100',
        icon: 'none',
        duration: 1000
      })
      return;
    }

    if (tPrice > 50000) {
      wx.showToast({
        title: '收款金额必须小50000',
        icon: 'none',
        duration: 1000
      })
      return;
    }

    var pages = getCurrentPages();
    var prevPage = pages[pages.length - 2];  //上一个页面
    //直接调用上一个页面的setData()方法，把数据存到上一个页面中去
    prevPage.setData({
      mPrice: tPrice
    })


    wx.navigateBack();   //返回上一个页面
  }
})