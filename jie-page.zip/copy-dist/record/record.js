// pages/record/record.js
Page({
	/**
   * 页面的初始数据
   */
	data: {
		isReq: false,
		mPage: 0
	},

	/**
   * 生命周期函数--监听页面加载
   */
	onLoad: function(options) {},

	/**
   * 生命周期函数--监听页面初次渲染完成
   */
	onReady: function() {},

	/**
   * 生命周期函数--监听页面显示
   */
	onShow: function() {
		var that = this
		if (!that.data.isReq) {
			that.setData({
				isReq: true
			})
			that.onReq()
		}
	},

	onReq: function() {
		var that = this
		wx.request({
			url: 'http://192.168.1.138:9001/ERPService.svc/DoService', // 获取收款记录
			data:
				'{"Message":{"Code":31019,"CountPerPage":10,"OrderByDescending":true,"OrderField":"OccurTime","Page":' +
				that.data.mPage +
				',"ServiceId":4,"SourceId":2}}',
			header: {
				'content-type': 'application/json',
				cookie: JSON.parse(wx.getStorageSync('sessionid'))[0]
			},
			method: 'POST',
			success(res) {
				// console.log(res.data.Message)
				if (res.data.Message.PayApiLogsGroup == null) {
				} else {
					if (that.data.recordItem == null) {
						var mList = res.data.Message.PayApiLogsGroup
						for (var i = 0; i < mList.length; i++) {
							var sTime =
								mList[i].PayApiLogItem.OccurTime.substring(0, 4) +
								'-' +
								mList[i].PayApiLogItem.OccurTime.substring(4, 6) +
								'-' +
								mList[i].PayApiLogItem.OccurTime.substring(6, 8)
							mList[i].PayApiLogItem.OccurTime = sTime
							//  console.log(mList[i].PayApiLogItem.OccurTime)
						}
						that.setData({
							recordItem: mList,
							isReq: false
						})
					} else {
						var mList = res.data.Message.PayApiLogsGroup
						for (var i = 0; i < mList.length; i++) {
							var sTime =
								mList[i].PayApiLogItem.OccurTime.substring(0, 4) +
								'-' +
								mList[i].PayApiLogItem.OccurTime.substring(4, 6) +
								'-' +
								mList[i].PayApiLogItem.OccurTime.substring(6, 8)
							mList[i].PayApiLogItem.OccurTime = sTime
							console.log(mList[i].PayApiLogItem.OccurTime)
						}
						that.setData({
							recordItem: that.data.recordItem.concat(mList),
							isReq: false
						})
					}
				}
			}
		})
	},

	/**
   * 生命周期函数--监听页面隐藏
   */
	onHide: function() {},

	/**
   * 生命周期函数--监听页面卸载
   */
	onUnload: function() {},

	/**
   * 页面相关事件处理函数--监听用户下拉动作
   */
	onPullDownRefresh: function() {},

	/**
   * 页面上拉触底事件的处理函数
   */
	onReachBottom: function() {},

	onDownListener: function() {
		var that = this
		if (!that.data.isReq) {
			that.setData({
				isReq: true,
				mPage: that.data.mPage + 1
			})
			that.onReq()
		}
	},

	/**
   * 用户点击右上角分享
   */
	onShareAppMessage: function() {}
})
